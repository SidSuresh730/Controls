function f = ts2wn(ts, z)
    f = 4/(z*ts)